import React, { useEffect, useState } from "react";

function MyBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({
    name: "",
    checkIn: "",
    checkOut: "",
    guests: 1,
    phone: "",
  });

 
  useEffect(() => {
    fetch("http://localhost:5000/api/bookings") 
      .then((res) => {
        if (!res.ok) {
          throw new Error("Failed to fetch bookings");
        }
        return res.json();
      })
      .then((data) => {
        setBookings(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

 
  const handleDelete = async (bookingId) => {
    if (!window.confirm("Are you sure you want to delete this booking?")) return;

    try {
      const res = await fetch(`http://localhost:5000/api/bookings/${bookingId}`, {
        method: "DELETE",
      });

      if (!res.ok) throw new Error("Failed to delete");

      setBookings((prev) => prev.filter((b) => b._id !== bookingId));
      alert("Booking deleted!");
    } catch (err) {
      alert("Error deleting booking: " + err.message);
    }
  };

  
  const startEditing = (booking) => {
    setEditingId(booking._id);
    setEditData({
      name: booking.name,
      checkIn: booking.checkIn.slice(0, 10), 
      checkOut: booking.checkOut.slice(0, 10),
      guests: booking.guests,
      phone: booking.phone,
    });
  };

  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditData((prev) => ({ ...prev, [name]: value }));
  };

  
  const saveEdit = async () => {
    try {
      const res = await fetch(`http://localhost:5000/api/bookings/${editingId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(editData),
      });

      if (!res.ok) throw new Error("Failed to update booking");

      const updatedBooking = await res.json();

      setBookings((prev) =>
        prev.map((b) => (b._id === editingId ? updatedBooking : b))
      );
      setEditingId(null);
      alert("Booking updated!");
    } catch (err) {
      alert("Error updating booking: " + err.message);
    }
  };

  
  const cancelEdit = () => {
    setEditingId(null);
  };

  if (loading) return <p>Loading your bookings...</p>;
  if (error) return <p style={{ color: "red" }}>Error: {error}</p>;

  return (
    <div style={{ padding: "20px" }}>
      <h2>My Bookings</h2>
      {bookings.length === 0 ? (
        <p>You have no bookings yet.</p>
      ) : (
        <table border="1" cellPadding="10">
          <thead>
            <tr>
              <th>Name</th>
              <th>Check In</th>
              <th>Check Out</th>
              <th>Guests</th>
              <th>Phone</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((booking) => (
              <tr key={booking._id}>
                {editingId === booking._id ? (
                  <>
                    <td>
                      <input
                        type="text"
                        name="name"
                        value={editData.name}
                        onChange={handleChange}
                      />
                    </td>
                    <td>
                      <input
                        type="date"
                        name="checkIn"
                        value={editData.checkIn}
                        onChange={handleChange}
                      />
                    </td>
                    <td>
                      <input
                        type="date"
                        name="checkOut"
                        value={editData.checkOut}
                        onChange={handleChange}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        name="guests"
                        min="1"
                        value={editData.guests}
                        onChange={handleChange}
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        name="phone"
                        value={editData.phone}
                        onChange={handleChange}
                      />
                    </td>
                    <td>
                      <button onClick={saveEdit}>Save</button>
                      <button onClick={cancelEdit}>Cancel</button>
                    </td>
                  </>
                ) : (
                  <>
                    <td>{booking.name}</td>
                    <td>{new Date(booking.checkIn).toLocaleDateString()}</td>
                    <td>{new Date(booking.checkOut).toLocaleDateString()}</td>
                    <td>{booking.guests}</td>
                    <td>{booking.phone}</td>
                    <td>
                      <button onClick={() => startEditing(booking)}>Edit</button>
                      <button onClick={() => handleDelete(booking._id)}>Delete</button>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default MyBookings;
