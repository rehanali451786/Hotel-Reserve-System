
import React, { useEffect, useState } from "react";

function BookingsList() {
  const [bookings, setBookings] = useState([]);
  const [filteredBookings, setFilteredBookings] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingBooking, setEditingBooking] = useState(null);
  const [editFormData, setEditFormData] = useState({
    name: "",
    email: "",
    phone: "",
    checkIn: "",
    checkOut: "",
    guests: 1,
  });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = () => {
    setLoading(true);
    setError(null);

    fetch("http://localhost:5000/api/bookings")
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch bookings");
        return res.json();
      })
      .then((data) => {
        setBookings(data);
        setFilteredBookings(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching bookings:", err);
        setError(err.message || "Error fetching bookings");
        setLoading(false);
      });
  };

  const handleSearch = (e) => {
    const value = e.target.value.toLowerCase();
    setSearchTerm(value);

    const filtered = bookings.filter((booking) =>
      booking.name.toLowerCase().includes(value) ||
      booking.email.toLowerCase().includes(value) ||
      booking.phone.toLowerCase().includes(value)
    );

    setFilteredBookings(filtered);
  };

  const deleteBooking = (id) => {
    if (!window.confirm("Are you sure you want to delete this booking?")) return;

    fetch(`http://localhost:5000/api/bookings/${id}`, {
      method: "DELETE",
    })
      .then((res) => {
        if (res.ok) {
          alert("Booking deleted successfully!");
          fetchBookings();
        } else {
          alert("Failed to delete booking.");
        }
      })
      .catch((err) => {
        console.error("Error deleting booking:", err);
        alert("Something went wrong.");
      });
  };

  const startEditing = (booking) => {
    setEditingBooking(booking._id);
    setEditFormData({
      name: booking.name,
      email: booking.email,
      phone: booking.phone,
      checkIn: booking.checkIn.slice(0, 10),
      checkOut: booking.checkOut.slice(0, 10),
      guests: booking.guests,
    });
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleEditSubmit = (e) => {
    e.preventDefault();

    fetch(`http://localhost:5000/api/bookings/${editingBooking}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(editFormData),
    })
      .then((res) => {
        if (res.ok) {
          alert("Booking updated successfully!");
          setEditingBooking(null);
          fetchBookings();
        } else {
          alert("Failed to update booking.");
        }
      })
      .catch((err) => {
        console.error("Error updating booking:", err);
        alert("Something went wrong.");
      });
  };

  const cancelEdit = () => {
    setEditingBooking(null);
  };

  if (loading) return <p>Loading bookings...</p>;
  if (error) return <p style={{ color: "red" }}>Error: {error}</p>;

  return (
    <div style={{ padding: "20px" }}>
      <h2>Bookings</h2>

      <input
        type="text"
        placeholder="Search by name, email, or phone"
        value={searchTerm}
        onChange={handleSearch}
        style={{
          padding: "8px",
          marginBottom: "15px",
          width: "300px",
          fontSize: "16px",
        }}
      />

      {filteredBookings.length === 0 ? (
        <p>No bookings found.</p>
      ) : (
        <table border="1" cellPadding="10">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Check-In</th>
              <th>Check-Out</th>
              <th>Guests</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredBookings.map((booking) =>
              editingBooking === booking._id ? (
                <tr key={booking._id}>
                  <td>
                    <input
                      type="text"
                      name="name"
                      value={editFormData.name}
                      onChange={handleEditChange}
                    />
                  </td>
                  <td>
                    <input
                      type="email"
                      name="email"
                      value={editFormData.email}
                      onChange={handleEditChange}
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      name="phone"
                      value={editFormData.phone}
                      onChange={handleEditChange}
                    />
                  </td>
                  <td>
                    <input
                      type="date"
                      name="checkIn"
                      value={editFormData.checkIn}
                      onChange={handleEditChange}
                    />
                  </td>
                  <td>
                    <input
                      type="date"
                      name="checkOut"
                      value={editFormData.checkOut}
                      onChange={handleEditChange}
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      name="guests"
                      min="1"
                      value={editFormData.guests}
                      onChange={handleEditChange}
                    />
                  </td>
                  <td>
                    <button onClick={handleEditSubmit} style={{ marginRight: "5px" }}>
                      Save
                    </button>
                    <button
                      onClick={cancelEdit}
                      style={{ backgroundColor: "gray", color: "white" }}
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ) : (
                <tr key={booking._id}>
                  <td>{booking.name}</td>
                  <td>{booking.email}</td>
                  <td>{booking.phone}</td>
                  <td>{new Date(booking.checkIn).toLocaleDateString()}</td>
                  <td>{new Date(booking.checkOut).toLocaleDateString()}</td>
                  <td>{booking.guests}</td>
                  <td>
                    <button
                      onClick={() => startEditing(booking)}
                      style={{ marginRight: "5px" }}
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => deleteBooking(booking._id)}
                      style={{ backgroundColor: "red", color: "white" }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              )
            )}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default BookingsList;
