
import React from 'react';
import './Rooms.css'; 
import room1 from '../pages/Images/room1.jpg';
import room2 from '../pages/Images/room2.jpg';
import room3 from '../pages/Images/room3.jpg';
import room4 from '../pages/Images/room4.jpg';
import room5 from '../pages/Images/room5.jpg';
import room6 from '../pages/Images/room6.jpg';

function Rooms() {
  return (
    <section className="rooms">
      <h2>Our Rooms</h2>
      <div className="room-list">
        <div className="room">
          <img src={room1} alt="Room 1" />
          <h3>Standard Room</h3>
          <p>Comfortable room with basic facilities.</p>
        </div>
        <div className="room">
          <img src={room2} alt="Room 2" />
          <h3>Deluxe Room</h3>
          <p>Spacious room with luxury features.</p>
        </div>
        <div className="room">
          <img src={room3} alt="Room 3" />
          <h3>Suite</h3>
          <p>Top-tier suite for premium guests.</p>
        </div>
                <div className="room">
          <img src={room4} alt="Room 4" />
          <h3>The Royal Wood Haven</h3>
          <p>Warm wood interiors for a classy stay.</p>
        </div>
        <div className="room">
          <img src={room5} alt="Room 5" />
          <h3>Nature Panorama Suite</h3>
          <p>Lake views & pure natural serenity.</p>
        </div>
        <div className="room">
          <img src={room6} alt="Room 6" />
          <h3>Sunset Royal Penthouse</h3>
          <p>Romantic glass suite with ocean sunsets.</p>
        </div>
      </div>
    </section>
  );
}

export default Rooms;

