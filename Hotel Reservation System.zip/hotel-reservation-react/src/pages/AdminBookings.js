// src/pages/AdminBookings.js
import React, { useEffect, useState } from "react";
import UploadRoomImage from "../components/UploadRoomImage";

const AdminBookings = () => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/bookings");
      const data = await res.json();
      setBookings(data);
    } catch (error) {
      console.error("Failed to fetch bookings:", error);
    }
  };

  return (
    <div className="bookings-container">
      <h2>All Bookings (Admin View)</h2>

      {/* Upload Room Image Option for Admin */}
      <div style={{ marginBottom: "30px", border: "1px solid #ccc", padding: "20px" }}>
        <h3>Upload Room Picture</h3>
        <UploadRoomImage />
      </div>

      {/* Display All Bookings */}
      {bookings.length === 0 ? (
        <p>No bookings found.</p>
      ) : (
        <table>
          <thead>
            <tr>
              <th>Customer</th>
              <th>Room</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((booking) => (
              <tr key={booking._id}>
                <td>{booking.name}</td>
                <td>{booking.roomType}</td>
                <td>{booking.date}</td>
                <td>
                  {/* Add Delete/Edit here later */}
                  <button>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default AdminBookings;
