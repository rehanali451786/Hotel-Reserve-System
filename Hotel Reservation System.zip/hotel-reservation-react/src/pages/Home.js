// Home.js
import React from 'react';
import Hero from '../components/Hero';
import Features from '../components/Features';
import ClientFeedback from '../components/ClientFeedback';

const Home = () => {
  return (
    <div>
      <Hero />
      <Features />
      <ClientFeedback />
    </div>
  );
};

export default Home;
