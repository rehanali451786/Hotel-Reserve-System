import React, { useState } from 'react';
import './Login.css';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

const handleSubmit = async (e) => {
  e.preventDefault();

  try {
    const response = await fetch("http://localhost:5000/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });

    const data = await response.json();

    if (response.ok) {
      
      localStorage.setItem("loggedInUser", JSON.stringify(data.user));
      localStorage.setItem("token", data.token);

      if (data.user.isAdmin) {
        window.location.href = "/admin/dashboard";  
      } else {
        window.location.href = "/bookings"; 
      }
    } else {
      alert(data.message || "Login failed!");
    }
  } catch (error) {
    alert("Something went wrong.");
  }
};


  return (
    <div className="login-section">
      <h2>Login to Your Account</h2>
      <form onSubmit={handleSubmit} className="login-form">
        <label>
          Email:
          <input 
            type="email" 
            name="email" 
            value={formData.email} 
            onChange={handleChange} 
            required 
            placeholder="Enter your email"
          />
        </label>

        <label>
          Password:
          <input 
            type="password" 
            name="password" 
            value={formData.password} 
            onChange={handleChange} 
            required 
            placeholder="Enter your password"
          />
        </label>

        <button type="submit" className="btn-submit">Login</button>
      </form>
    </div>
  );
};

export default Login;
