
const express = require("express");
const router = express.Router();
const Booking = require("../models/Booking");


router.post("/", async (req, res) => {
  try {
    const { name, email, phone, checkIn, checkOut, guests } = req.body;

    if (!name || !email || !phone || !checkIn || !checkOut || !guests)
      return res.status(400).json({ message: "Missing required fields" });

    const newBooking = new Booking({
      name,
      email,
      phone,
      checkIn,
      checkOut,
      guests,
    });

    await newBooking.save();
    res.status(201).json({ message: "Booking created", booking: newBooking });
  } catch (err) {
    console.error("Error creating booking:", err);
    res.status(500).json({ message: "Failed to create booking" });
  }
});


router.get("/", async (req, res) => {
  try {
    const bookings = await Booking.find();
    res.json(bookings);
  } catch (err) {
    console.error("Error fetching bookings:", err);
    res.status(500).json({ message: "Failed to fetch bookings" });
  }
});


router.get("/by-userid", async (req, res) => {
  try {
    const { userId } = req.query;
    if (!userId) return res.status(400).json({ message: "Missing userId" });

    const bookings = await Booking.find({ user: userId });
    res.json(bookings);
  } catch (err) {
    console.error("Error fetching bookings by userId:", err);
    res.status(500).json({ message: "Failed to fetch bookings" });
  }
});


router.get("/search", async (req, res) => {
  try {
    const { q } = req.query;

    if (!q) {
      return res.status(400).json({ message: "Missing search query" });
    }

    
    const regex = new RegExp(q, "i");

    const bookings = await Booking.find({
      $or: [
        { name: regex },
        { email: regex },
        { phone: regex },
      ],
    });

    res.json(bookings);
  } catch (err) {
    console.error("Error searching bookings:", err);
    res.status(500).json({ message: "Failed to search bookings" });
  }
});


router.put("/:id", async (req, res) => {
  try {
    const updatedBooking = await Booking.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!updatedBooking)
      return res.status(404).json({ message: "Booking not found" });

    res.json({ message: "Booking updated", booking: updatedBooking });
  } catch (err) {
    console.error("Error updating booking:", err);
    res.status(500).json({ message: "Failed to update booking" });
  }
});


router.delete("/:id", async (req, res) => {
  try {
    const deletedBooking = await Booking.findByIdAndDelete(req.params.id);
    if (!deletedBooking)
      return res.status(404).json({ message: "Booking not found" });

    res.json({ message: "Booking deleted" });
  } catch (err) {
    console.error("Error deleting booking:", err);
    res.status(500).json({ message: "Failed to delete booking" });
  }
});

module.exports = router;
