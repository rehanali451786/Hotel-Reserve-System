const express = require("express");
const router = express.Router();
const {
  getUserBookings,
  updateBooking,
  deleteBooking,
} = require("../controllers/userController");


router.get("/:email", getUserBookings);

router.put("/:id", updateBooking);


router.delete("/:id", deleteBooking);

module.exports = router;
