import React from "react";

const roomsData = [
  {
    img: "room2.jpg",
    title: "The Urban Luxe Suite",
    desc: "City views, modern design & ultimate comfort.",
  },
  {
    img: "room3.jpg",
    title: "Ocean Breeze Retreat",
    desc: "Beachfront bliss with bright, airy vibes.",
  },
  {
    img: "room4.jpg",
    title: "The Royal Wood Haven",
    desc: "Warm wood interiors for a classy stay.",
  },
  {
    img: "room5.jpg",
    title: "Nature Panorama Suite",
    desc: "Lake views & pure natural serenity.",
  },
  {
    img: "room7.jpg",
    title: "Skyline Ocean Suite",
    desc: "Stylish space with stunning sea views.",
  },
  {
    img: "room6.jpg",
    title: "Sunset Royal Penthouse",
    desc: "Romantic glass suite with ocean sunsets.",
  },
];

export default function Rooms() {
  return (
    <section className="py-5 bg-light">
      <div className="container">
        <h2 className="text-center mb-5">Our Rooms</h2>
        <div className="row g-4">
          {roomsData.map((room, index) => (
            <div className="col-md-4" key={index}>
              <div className="card h-100 shadow-sm">
                <img
                  src={room.img}
                  className="card-img-top"
                  alt={room.title}
                />
                <div className="card-body">
                  <h5 className="card-title">{room.title}</h5>
                  <p className="card-text">{room.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
