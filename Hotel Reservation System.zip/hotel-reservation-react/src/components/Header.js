import React, { useEffect, useState } from 'react';
import LogoutButton from '../pages/LogoutButton';
import './Header.css';

const Header = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loggedIn = JSON.parse(localStorage.getItem('loggedInUser'));
    setUser(loggedIn);
  }, []);

  return (
    <header className="main-header">
      <div className="container header-container">
        <div className="logo">OceanView Hotels</div>
        <nav className="nav-links">
          <a href="/" className="nav-link">Home</a>
          <a href="/rooms" className="nav-link">Rooms</a>
          <a href="/booking" className="nav-link">Booking</a>
          <a href="/contact" className="nav-link">Contact</a>

          {user ? (
            <>
              <a href="/bookings" className="nav-link">My Bookings</a>
              <LogoutButton />
            </>
          ) : (
            <>
              <a href="/login" className="btn-login">Login</a>
              <a href="/register" className="btn-register">Register</a>
            </>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;
