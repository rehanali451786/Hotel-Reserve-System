
import React from "react";
import "./ClientFeedback.css";  
import emmaImg from '../pages/Images/emma.jpg';
import saraImg from '../pages/Images/sara.jpg';
import michealImg from '../pages/Images/micheal.jpg';

const feedbackData = [
  {
    id: 1,
    name: "Emma",
    feedback:
      "Great experience! The rooms were clean and the staff was very friendly.",
    img: emmaImg ,
  },
  {
    id: 2,
    name: "Sara Ahmed",
    feedback:
      "Loved the location and the services. Will definitely come back!",
    img: saraImg,
  },
  {
    id: 3,
    name: "Micheal",
    feedback:
      "Affordable prices and excellent customer support.",
    img: michealImg,
  },
];

const ClientFeedback = () => {
  return (
    <section className="client-feedback">
      <h2>Client Feedback</h2>
      <div className="feedback-grid">
        {feedbackData.map(({ id, name, feedback, img }) => (
          <div key={id} className="feedback-card">
            <img src={img} alt={name} />
            <h3>{name}</h3>
            <p>{feedback}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ClientFeedback;
