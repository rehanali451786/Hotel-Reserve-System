
import React from 'react';
import './Hero.css'; 

function Hero() {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>Welcome to OceanView Hotels Hotel</h1>
        <p>Experience luxury and comfort like never before</p>
        <a className="hero-btn" href="/booking">Book Now</a>
      </div>
    </section>
  );
}

export default Hero;
