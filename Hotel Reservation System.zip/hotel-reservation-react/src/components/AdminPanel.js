
import React from "react";
import { Link } from "react-router-dom";


function AdminPanel() {
  return (
    <div className="container mt-5">
      <h2>Admin Panel</h2>
      <ul className="list-group">
        <li className="list-group-item">
          <Link to="/bookingslist">Manage Bookings</Link>
        </li>
        <li className="list-group-item">
          <Link to="/users">Manage Users</Link>
        </li>
      </ul>
    </div>
  );
}

export default AdminPanel;
