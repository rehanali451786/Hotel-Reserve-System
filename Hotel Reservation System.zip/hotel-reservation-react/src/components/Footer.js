import React from "react";
import './Footer.css'; 

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div>
          <h2 className="footer-title">OceanView Hotels</h2>
          <p className="footer-copy">&copy; {new Date().getFullYear()} All rights reserved.</p>
        </div>
        <div className="footer-links">
          <a href="/rooms">Rooms</a>
          <a href="/booking">Booking</a>
          <a href="/contact">Contact</a>
          <a href="/login">Login</a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
