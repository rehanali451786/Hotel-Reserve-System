import React from 'react';
import './Features.css'; 
import LuxuryRoom from '../pages/Images/LuxuryRoom.avif';
import FineDining from '../pages/Images/FineDining.avif';
import pic4 from '../pages/Images/pic4.avif';
const Features = () => {
  return (
    <section className="features">
      <div className="container">
        <h2>Our Hotel Features</h2>
        <div className="feature-grid">
          <div className="feature-card">
            <img src = {LuxuryRoom} alt="Feature 1" />
            <h3>Luxury Rooms</h3>
            <p>Experience comfort and luxury in our well-furnished rooms.</p>
          </div>
          <div className="feature-card">
            <img src={FineDining} alt="Feature 2" />
            <h3>Delicious Food</h3>
            <p>Enjoy a variety of delicious meals prepared by top chefs.</p>
          </div>
          <div className="feature-card">
            <img src={pic4} alt="Feature 3" />
            <h3>Swimming Pool</h3>
            <p>Relax in our clean and refreshing swimming pool.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
